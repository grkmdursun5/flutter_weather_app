plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.example.weather_app"
    compileSdk = 35
    ndkVersion = "27.0.12077973"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        applicationId = "com.example.weather_app"
        minSdk = 21               // Konum için yeterli
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        // Multidex desteği
        multiDexEnabled = true
    }

    buildTypes {
        release {
            // Debug ile çalışacak, istersen signingConfig değiştir
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    // Multidex desteği için gerekli
    implementation("androidx.multidex:multidex:2.0.1")
}