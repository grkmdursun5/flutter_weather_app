import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'main.dart';

class ComparePage extends StatefulWidget {
  const ComparePage({super.key});
  @override
  State<ComparePage> createState() => _ComparePageState();
}

class _ComparePageState extends State<ComparePage> {
  final TextEditingController _city1 = TextEditingController();
  final TextEditingController _city2 = TextEditingController();
  Map<String, dynamic>? w1, w2;
  bool loading = false;
  bool useF = false;

  @override
  void initState() {
    super.initState();
    Prefs.init().then((_) => setState(() => useF = Prefs.isF));
  }

  Future<void> _compare() async {
    if (_city1.text.isEmpty || _city2.text.isEmpty) return;
    HapticFeedback.lightImpact();
    setState(() => loading = true);
    const apiKey = '9ff6079d01fb466c9d2161301251208';

    final url1 = Uri.parse(
        'https://api.weatherapi.com/v1/forecast.json?key=$apiKey&q=${Uri.encodeComponent(_city1.text)}&days=7&lang=tr');
    final url2 = Uri.parse(
        'https://api.weatherapi.com/v1/forecast.json?key=$apiKey&q=${Uri.encodeComponent(_city2.text)}&days=7&lang=tr');

    try {
      final res1 = await http.get(url1);
      final res2 = await http.get(url2);
      if (res1.statusCode == 200 && res2.statusCode == 200) {
        setState(() {
          w1 = json.decode(utf8.decode(res1.bodyBytes));
          w2 = json.decode(utf8.decode(res2.bodyBytes));
        });
      }
    } catch (_) {} finally {
      setState(() => loading = false);
    }
  }

  Widget _cityField(TextEditingController ctrl, String hint) => Expanded(
    child: TextField(
      controller: ctrl,
      style: TextStyle(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Colors.black),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white70
                : Colors.black54),
        filled: true,
        fillColor: Theme.of(context).brightness == Brightness.dark
            ? Colors.white.withOpacity(0.15)
            : Colors.black.withOpacity(0.05),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(24),
          borderSide: BorderSide.none,
        ),
        contentPadding:
        const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      ),
    ),
  );

  Widget _infoCard(Map<String, dynamic>? w, String city) {
    if (w == null) return const SizedBox();
    final c = w['current'];
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(26),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: isDark
                ? Colors.white.withOpacity(0.15)
                : Colors.white.withOpacity(0.7),
            borderRadius: BorderRadius.circular(26),
            border: Border.all(
                color: isDark
                    ? Colors.white.withOpacity(0.4)
                    : Colors.black.withOpacity(0.2),
                width: 1.2),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(w['location']['name'],
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: isDark ? Colors.white : Colors.black)),
              const SizedBox(height: 8),
              Image.network('https:${c['condition']['icon']}',
                  width: 64, height: 64),
              const SizedBox(height: 8),
              Text(Temp.fmt(c['temp_c'], useF),
                  style: TextStyle(
                      fontSize: 42,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : Colors.black)),
              Text(c['condition']['text'],
                  style: TextStyle(
                      fontSize: 16,
                      color: isDark ? Colors.white70 : Colors.black54)),
              const SizedBox(height: 12),
              _statRow('Hissedilen', Temp.fmt(c['feelslike_c'], useF),
                  isDark),
              _statRow('Nem', '${c['humidity']}%', isDark),
              _statRow('Rüzgar', '${c['wind_kph'].round()} km/s', isDark),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statRow(String label, String value, bool isDark) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(
                color: isDark ? Colors.white70 : Colors.black54)),
        Text(value,
            style: TextStyle(
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white : Colors.black)),
      ],
    ),
  );

  Widget _mini7(Map<String, dynamic>? w) {
    if (w == null) return const SizedBox();
    final days = w['forecast']['forecastday'] as List;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 8),
          child: Text('${w['location']['name']} - 7 Gün',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.white : Colors.black)),
        ),
        SizedBox(
          height: 140,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            itemCount: days.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) {
              final d = days[i];
              return Container(
                width: 100,
                decoration: BoxDecoration(
                  color: isDark
                      ? Colors.white.withOpacity(0.15)
                      : Colors.white.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: isDark
                          ? Colors.white.withOpacity(0.4)
                          : Colors.black.withOpacity(0.2)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      DateFormat('EEE', 'tr_TR').format(
                          DateTime.fromMillisecondsSinceEpoch(
                              d['date_epoch'] * 1000)),
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: isDark ? Colors.white : Colors.black),
                    ),
                    const SizedBox(height: 6),
                    Image.network('https:${d['day']['condition']['icon']}',
                        width: 36, height: 36),
                    const SizedBox(height: 6),
                    Text('${Temp.fmt(d['day']['maxtemp_c'], useF)}°',
                        style: TextStyle(
                            color: isDark ? Colors.white : Colors.black,
                            fontSize: 14)),
                    Text('${Temp.fmt(d['day']['mintemp_c'], useF)}°',
                        style: TextStyle(
                            color:
                            isDark ? Colors.white70 : Colors.black54,
                            fontSize: 12)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top + kToolbarHeight + 8;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isDark
              ? const [Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)]
              : const [Color(0xFF2196F3), Color(0xFF64B5F6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new,
                color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: const Text(
            'Şehir Karşılaştırma',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              shadows: [
                Shadow(
                    offset: Offset(1, 1),
                    blurRadius: 3,
                    color: Colors.black45)
              ],
            ),
          ),
        ),
        body: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(16, topPadding, 16, 16),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight,
                ),
                child: IntrinsicHeight(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          _cityField(_city1, '1. Şehir'),
                          const SizedBox(width: 12),
                          _cityField(_city2, '2. Şehir'),
                        ],
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepPurpleAccent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 16),
                          ),
                          onPressed: loading ? null : _compare,
                          child: loading
                              ? const CircularProgressIndicator(
                              color: Colors.white)
                              : const Text(
                            'KARŞILAŞTIR',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      if (w1 != null || w2 != null)
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(child: _infoCard(w1, _city1.text)),
                            const SizedBox(width: 12),
                            Expanded(child: _infoCard(w2, _city2.text)),
                          ],
                        ),
                      const SizedBox(height: 20),
                      if (w1 != null) _mini7(w1),
                      if (w1 != null && w2 != null) const SizedBox(height: 20),
                      if (w2 != null) _mini7(w2),
                      const SizedBox(height: 30),
                      const Spacer(),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}