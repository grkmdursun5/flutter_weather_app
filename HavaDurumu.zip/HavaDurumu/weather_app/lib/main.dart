import 'dart:ui';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:url_launcher/url_launcher.dart';

import 'login_page.dart';
import 'compare_page.dart';

const String apiKey = '9ff6079d01fb466c9d2161301251208';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('tr_TR', null);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hava Durumu',
      theme: FlexColorScheme.light(useMaterial3: true).toTheme,
      darkTheme: FlexColorScheme.dark(useMaterial3: true).toTheme,
      themeMode: ThemeMode.system,
      home: const _CheckAuth(),
      routes: {
        '/home': (_) => const _RootWeather(),
        '/login': (_) => const LoginPage()
      },
    );
  }
}

class _CheckAuth extends StatelessWidget {
  const _CheckAuth();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<SharedPreferences>(
      future: SharedPreferences.getInstance(),
      builder: (context, snapshot) => snapshot.connectionState ==
          ConnectionState.waiting
          ? const Scaffold(
          body: Center(child: CircularProgressIndicator()))
          : (snapshot.data?.getBool('isLoggedIn') ?? false)
          ? const _RootWeather()
          : const LoginPage(),
    );
  }
}

class _RootWeather extends StatefulWidget {
  const _RootWeather();
  @override
  State<_RootWeather> createState() => _RootWeatherState();
}

class _RootWeatherState extends State<_RootWeather> {
  bool _dark = true, _random = false;
  @override
  void initState() {
    super.initState();
    Prefs.init().then((_) => setState(() => _dark = Prefs.isDark));
  }

  void _toggleTheme(bool dark) => setState(() => _dark = dark);
  void _toggleRandom(bool random) => setState(() => _random = random);

  Future<void> _logout(BuildContext ctx) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', false);
    Navigator.of(ctx).pushReplacementNamed('/login');
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hava Durumu',
      theme: _random
          ? FlexColorScheme.light(
        colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.primaries[Random().nextInt(Colors.primaries.length)]),
        useMaterial3: true,
      ).toTheme
          : FlexColorScheme.light(useMaterial3: true).toTheme,
      darkTheme: _random
          ? FlexColorScheme.dark(
        colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.primaries[Random().nextInt(Colors.primaries.length)],
            brightness: Brightness.dark),
        useMaterial3: true,
      ).toTheme
          : FlexColorScheme.dark(useMaterial3: true).toTheme,
      themeMode: _dark ? ThemeMode.dark : ThemeMode.light,
      home: WeatherPage(
          onThemeChanged: _toggleTheme,
          toggleRandomTheme: _toggleRandom,
          onLogout: () => _logout(context)),
    );
  }
}

class Temp {
  static double toF(double c) => c * 9 / 5 + 32;
  static String fmt(double val, bool isF) =>
      '${(isF ? toF(val) : val).round()}°${isF ? 'F' : 'C'}';
}

class Prefs {
  static late SharedPreferences _prefs;
  static Future<void> init() async =>
      _prefs = await SharedPreferences.getInstance();

  static bool get isF => _prefs.getBool('useFahrenheit') ?? false;
  static Future<void> setIsF(bool val) =>
      _prefs.setBool('useFahrenheit', val);

  static bool get isDark => _prefs.getBool('darkTheme') ?? true;
  static Future<void> setTheme(bool dark) =>
      _prefs.setBool('darkTheme', dark);

  static List<String> get recent => _prefs.getStringList('recent') ?? [];
  static Future<void> addRecent(String city) {
    final list = [...recent];
    list.remove(city);
    list.insert(0, city);
    if (list.length > 5) list.removeLast();
    return _prefs.setStringList('recent', list);
  }

  static List<String> get favorites =>
      _prefs.getStringList('favorites') ?? [];
  static Future<void> setFavorites(List<String> list) =>
      _prefs.setStringList('favorites', list);
}

class WeatherPage extends StatefulWidget {
  final Function(bool) onThemeChanged;
  final Function(bool) toggleRandomTheme;
  final VoidCallback onLogout;
  const WeatherPage(
      {super.key,
        required this.onThemeChanged,
        required this.toggleRandomTheme,
        required this.onLogout});
  @override
  State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _hourlyScroll = ScrollController();
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  Map<String, dynamic>? weatherData;
  List<dynamic>? hourlyForecast;
  List<dynamic>? dailyForecast;
  bool isLoading = false;
  String errorMessage = '';
  bool useF = false;
  List<String> _favorites = [];

  @override
  void initState() {
    super.initState();
    Prefs.init().then((_) {
      setState(() => useF = Prefs.isF);
      _loadFavorites();
      _getLocationAndWeather();
    });
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _scrollToCurrentHour());
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _favorites = prefs.getStringList('favorites') ?? []);
  }

  Future<void> _toggleFavorite(String city) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (_favorites.contains(city)) {
        _favorites.remove(city);
      } else {
        _favorites.insert(0, city);
      }
    });
    await prefs.setStringList('favorites', _favorites);
  }

  void _scrollToCurrentHour() {
    if (hourlyForecast == null || weatherData == null) return;
    DateTime cityNow;
    try {
      cityNow = DateTime.parse(weatherData!['location']['localtime']);
    } catch (_) {
      cityNow = DateTime.now();
    }
    int idx = 0;
    for (int i = 0; i < hourlyForecast!.length; i++) {
      try {
        final t = DateTime.parse(hourlyForecast![i]['time']);
        if (t.year == cityNow.year &&
            t.month == cityNow.month &&
            t.day == cityNow.day &&
            t.hour == cityNow.hour) {
          idx = i;
          break;
        }
      } catch (_) {}
    }
    _hourlyScroll.jumpTo(idx * 98.0);
  }

  Future<void> _getLocationAndWeather() async {
    setState(() => isLoading = true);
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      setState(() {
        errorMessage = 'Konum servisi kapalı.';
        isLoading = false;
      });
      fetchWeather('Istanbul');
      return;
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      setState(() {
        errorMessage = 'Konum izni verilmedi.';
        isLoading = false;
      });
      fetchWeather('Istanbul');
      return;
    }
    final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    fetchWeather('${pos.latitude},${pos.longitude}');
  }

  Future<void> fetchWeather(String query) async {
    if (query.isEmpty) return;
    setState(() {
      isLoading = true;
      errorMessage = '';
      weatherData = null;
      hourlyForecast = null;
      dailyForecast = null;
    });
    await Prefs.addRecent(query);
    final url = Uri.parse(
        'https://api.weatherapi.com/v1/forecast.json?key=  $apiKey&q=$query&days=7&lang=tr');
    try {
      final res = await http.get(url);
      if (res.statusCode == 200) {
        final data = json.decode(utf8.decode(res.bodyBytes));
        setState(() {
          weatherData = data;
          hourlyForecast = data['forecast']['forecastday'][0]['hour'];
          dailyForecast = data['forecast']['forecastday'];
          isLoading = false;
        });
        WidgetsBinding.instance
            .addPostFrameCallback((_) => _scrollToCurrentHour());
      } else {
        setState(() {
          errorMessage = 'Hava durumu alınamadı.';
          isLoading = false;
        });
      }
    } catch (_) {
      setState(() {
        errorMessage = 'Bağlantı hatası.';
        isLoading = false;
      });
    }
  }

  Future<void> _openMap() async {
    if (weatherData == null) return;
    final lat = weatherData!['location']['lat'];
    final lon = weatherData!['location']['lon'];
    final uri = Uri.parse(
        'https://www.openstreetmap.org/?mlat=  $lat&mlon=$lon&zoom=14');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _showSettingsSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) {
        bool tempF = useF;
        bool dark = Prefs.isDark;
        return StatefulBuilder(
          builder: (context, setSheet) => Container(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Ayarlar',
                    style:
                    TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                SwitchListTile(
                  title: const Text('Koyu Tema'),
                  value: dark,
                  onChanged: (val) {
                    setSheet(() => dark = val);
                    Prefs.setTheme(val);
                    widget.onThemeChanged(val);
                  },
                ),
                SwitchListTile(
                  title: const Text('Fahrenheit'),
                  value: tempF,
                  onChanged: (val) {
                    setSheet(() => tempF = val);
                    Prefs.setIsF(val);
                    setState(() => useF = val);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('Çıkış Yap'),
                  onTap: () {
                    Navigator.pop(context);
                    widget.onLogout();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showDetailsBottomSheet() {
    if (weatherData == null) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).brightness == Brightness.dark
          ? Colors.grey[900]
          : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 50,
                  height: 5,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const Text('Detaylar',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                  )),
              const SizedBox(height: 16),
              _detailRow(Icons.water_drop, 'Nem',
                  '${weatherData!['current']['humidity']}%'),
              _detailRow(Icons.compress, 'Basınç',
                  '${weatherData!['current']['pressure_mb']} hPa'),
              _detailRow(Icons.remove_red_eye, 'Görüş',
                  '${weatherData!['current']['vis_km']} km'),
              _detailRow(Icons.wb_sunny, 'UV',
                  '${weatherData!['current']['uv']}'),
              _detailRow(Icons.air, 'Rüzgar',
                  '${weatherData!['current']['wind_kph']} km/s'),
              const SizedBox(height: 25),
            ],
          ),
        );
      },
    );
  }

  Widget _detailRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: Colors.deepPurpleAccent, size: 26),
          const SizedBox(width: 16),
          Text(label,
              style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                  color: Colors.deepPurple)),
          const Spacer(),
          Text(value,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _altButon(IconData icon, String yazi, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(12),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white.withOpacity(0.05)
            : Colors.black.withOpacity(0.03),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon,
              size: 22, color: Theme.of(context).colorScheme.onSurface),
          const SizedBox(height: 4),
          Text(yazi,
              style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(context).colorScheme.onSurface)),
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final localTime = weatherData != null
        ? DateFormat('HH:mm', 'tr_TR')
        .format(DateTime.parse(weatherData!['location']['localtime']))
        : null;

    return Scaffold(
      key: _scaffoldKey,
      extendBodyBehindAppBar: true,
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.deepPurple),
              child: Text('Favori Şehirler',
                  style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ..._favorites.map(
                  (city) => Dismissible(
                key: Key(city),
                direction: DismissDirection.endToStart,
                onDismissed: (_) => _toggleFavorite(city),
                background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.white)),
                child: ListTile(
                  leading: const Icon(Icons.location_on_outlined),
                  title: Text(city),
                  onTap: () {
                    fetchWeather(city);
                    _scaffoldKey.currentState?.closeDrawer();
                  },
                ),
              ),
            ),
            if (_favorites.isEmpty)
              const ListTile(
                title: Text('Henüz favori yok'),
                enabled: false,
              )
          ],
        ),
      ),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.white),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: const Text('Hava Durumu',
            style: TextStyle(
                fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => fetchWeather(
              _controller.text.isEmpty
                  ? (weatherData?['location']['name'] ?? 'Istanbul')
                  : _controller.text,
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _showSettingsSheet,
            tooltip: 'Ayarlar',
          ),
        ],
      ),
      // 🔥 SAĞ ALTA “Şehir Getir” butonu
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'fetchCity',
        backgroundColor: Colors.deepPurpleAccent,
        onPressed: () => fetchWeather(_controller.text),
        icon: const Icon(Icons.location_searching, color: Colors.white),
        label: const Text('Şehir Getir',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      bottomNavigationBar: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black.withOpacity(0.3)
                  : Colors.white.withOpacity(0.5),
              border: Border(
                top: BorderSide(
                  color: Theme.of(context).dividerColor.withOpacity(0.1),
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _altButon(Icons.map_outlined, 'Harita', _openMap),
                _altButon(Icons.compare_arrows, 'Şehir Karşılaştır', () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ComparePage()));
                }),
                _altButon(Icons.bar_chart, 'Haftalık Grafik', () {
                  if (dailyForecast != null) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => WeeklyChartPage(
                          dailyForecast: dailyForecast!,
                          useF: useF,
                        ),
                      ),
                    );
                  }
                }),
              ],
            ),
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => fetchWeather(
          _controller.text.isEmpty
              ? (weatherData?['location']['name'] ?? 'Istanbul')
              : _controller.text,
        ),
        child: SingleChildScrollView(
          controller: _scrollController,
          physics: const AlwaysScrollableScrollPhysics(),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: Theme.of(context).brightness == Brightness.dark
                    ? const [Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)]
                    : const [Color(0xFF2196F3), Color(0xFF64B5F6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _controller,
                            onSubmitted: (_) => fetchWeather(_controller.text),
                            decoration: InputDecoration(
                              hintText: 'Şehir Ara...',
                              filled: true,
                              fillColor: Theme.of(context).brightness ==
                                  Brightness.dark
                                  ? Colors.white.withOpacity(0.1)
                                  : Colors.white.withOpacity(0.9),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(25),
                                  borderSide: BorderSide.none),
                              prefixIcon: const Icon(Icons.search),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: Icon(
                            _favorites.contains(_controller.text.trim())
                                ? Icons.star
                                : Icons.star_border,
                            color: Colors.amber,
                            size: 28,
                          ),
                          onPressed: () {
                            final city = _controller.text.trim();
                            if (city.isNotEmpty) _toggleFavorite(city);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    if (isLoading)
                      const Center(
                          child: CircularProgressIndicator(color: Colors.white))
                    else if (weatherData == null)
                      Center(
                          child: Text(errorMessage,
                              style: const TextStyle(color: Colors.white)))
                    else
                      Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Theme.of(context).brightness ==
                                  Brightness.dark
                                  ? Colors.white.withOpacity(0.15)
                                  : Colors.white.withOpacity(0.7),
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: Column(
                              children: [
                                Text(weatherData!['location']['name'],
                                    style: TextStyle(
                                        fontSize: 38,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white
                                            : Colors.black)),
                                Text(
                                    '${weatherData!['location']['region']}, ${weatherData!['location']['country']}',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white70
                                            : Colors.black54)),
                                if (localTime != null)
                                  Text('Yerel saat: $localTime',
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Theme.of(context).brightness ==
                                              Brightness.dark
                                              ? Colors.white70
                                              : Colors.black54)),
                                const SizedBox(height: 10),
                                Image.network(
                                    'https:${weatherData!['current']['condition']['icon']}',
                                    width: 80,
                                    height: 80),
                                const SizedBox(height: 8),
                                Text(
                                    Temp.fmt(
                                        weatherData!['current']['temp_c'], useF),
                                    style: TextStyle(
                                        fontSize: 56,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white
                                            : Colors.black)),
                                Text(
                                    weatherData!['current']['condition']['text'],
                                    style: TextStyle(
                                        fontSize: 20,
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white70
                                            : Colors.black54)),
                                const SizedBox(height: 12),
                                Text(
                                    'Hissedilen: ${Temp.fmt(weatherData!['current']['feelslike_c'], useF)}',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white70
                                            : Colors.black54)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 15),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: _showDetailsBottomSheet,
                                icon: const Icon(Icons.info_outline,
                                    color: Colors.white),
                                label: const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 8.0),
                                  child: Text(
                                    'Detayları görmek için dokunun',
                                    style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.deepPurpleAccent,
                                  foregroundColor: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(35),
                                  ),
                                  elevation: 7,
                                  shadowColor:
                                  Colors.deepPurpleAccent.withOpacity(0.4),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          if (hourlyForecast != null &&
                              hourlyForecast!.isNotEmpty)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 4.0, bottom: 12.0),
                                  child: Text('Saatlik Tahmin',
                                      style: TextStyle(
                                          fontSize: 21,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white.withOpacity(0.95),
                                          shadows: const [
                                            Shadow(
                                                blurRadius: 1,
                                                color: Colors.black26,
                                                offset: Offset(0, 1))
                                          ])),
                                ),
                                SizedBox(
                                  height: 135,
                                  child: ListView.builder(
                                    controller: _hourlyScroll,
                                    scrollDirection: Axis.horizontal,
                                    itemCount: hourlyForecast!.length,
                                    physics: const BouncingScrollPhysics(),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 4),
                                    itemBuilder: (_, i) {
                                      final h = hourlyForecast![i];
                                      DateTime forecastTime;
                                      try {
                                        forecastTime = DateTime.parse(h['time']);
                                      } catch (_) {
                                        return const SizedBox.shrink();
                                      }
                                      DateTime cityNow = DateTime.parse(
                                          weatherData!['location']['localtime']);
                                      final bool isCurrentHour =
                                          cityNow.year == forecastTime.year &&
                                              cityNow.month ==
                                                  forecastTime.month &&
                                              cityNow.day == forecastTime.day &&
                                              cityNow.hour ==
                                                  forecastTime.hour;

                                      final String displayTime = isCurrentHour
                                          ? 'Şimdi'
                                          : DateFormat('HH:mm', 'tr_TR')
                                          .format(forecastTime);

                                      return Container(
                                        width: 90,
                                        margin: const EdgeInsets.only(right: 8),
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 10, horizontal: 5),
                                        decoration: BoxDecoration(
                                          color: isCurrentHour
                                              ? Colors.orangeAccent
                                              .withOpacity(0.85)
                                              : (Theme.of(context).brightness ==
                                              Brightness.dark
                                              ? Colors.white
                                              .withOpacity(0.12)
                                              : Colors.black
                                              .withOpacity(0.08)),
                                          borderRadius:
                                          BorderRadius.circular(22),
                                          border: Border.all(
                                            color: isCurrentHour
                                                ? Colors.white.withOpacity(0.9)
                                                : Colors.white.withOpacity(0.2),
                                            width: isCurrentHour ? 1.5 : 0.5,
                                          ),
                                          boxShadow: isCurrentHour
                                              ? [
                                            BoxShadow(
                                                color: Colors.orangeAccent
                                                    .withOpacity(0.3),
                                                blurRadius: 8,
                                                spreadRadius: 1)
                                          ]
                                              : [],
                                        ),
                                        child: Column(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(displayTime,
                                                style: TextStyle(
                                                    color: Colors.white
                                                        .withOpacity(
                                                        isCurrentHour
                                                            ? 1.0
                                                            : 0.9),
                                                    fontWeight: isCurrentHour
                                                        ? FontWeight.bold
                                                        : FontWeight.w500,
                                                    fontSize: isCurrentHour
                                                        ? 15
                                                        : 14)),
                                            Image.network(
                                              'https:${h['condition']['icon']}',
                                              width: 40,
                                              height: 40,
                                              errorBuilder: (_, __, ___) =>
                                              const Icon(
                                                  Icons.broken_image,
                                                  color: Colors.white54,
                                                  size: 30),
                                              loadingBuilder: (_, child,
                                                  loading) =>
                                              loading == null
                                                  ? child
                                                  : const SizedBox(
                                                  width: 20,
                                                  height: 20,
                                                  child:
                                                  CircularProgressIndicator(
                                                      strokeWidth:
                                                      2)),
                                            ),
                                            Text(Temp.fmt(h['temp_c'], useF),
                                                style: TextStyle(
                                                    color: Colors.white
                                                        .withOpacity(
                                                        isCurrentHour
                                                            ? 1.0
                                                            : 0.9),
                                                    fontWeight: isCurrentHour
                                                        ? FontWeight.bold
                                                        : FontWeight.w500,
                                                    fontSize: 15)),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          const SizedBox(height: 25),
                          if (dailyForecast != null && dailyForecast!.isNotEmpty)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('7 Günlük Tahmin',
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white)),
                                const SizedBox(height: 10),
                                SizedBox(
                                  height: 120,
                                  child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: dailyForecast!.length,
                                    itemBuilder: (context, i) {
                                      final d = dailyForecast![i];
                                      final date =
                                      DateTime.fromMillisecondsSinceEpoch(
                                          d['date_epoch'] * 1000);
                                      final dayName =
                                      DateFormat('EEE', 'tr_TR')
                                          .format(date);
                                      return Container(
                                        width: 100,
                                        margin: const EdgeInsets.only(right: 10),
                                        padding: const EdgeInsets.all(12),
                                        decoration: BoxDecoration(
                                          color: Theme.of(context).brightness ==
                                              Brightness.dark
                                              ? Colors.white.withOpacity(0.15)
                                              : Colors.white.withOpacity(0.7),
                                          borderRadius:
                                          BorderRadius.circular(15),
                                        ),
                                        child: Column(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Text(dayName,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    color: Theme.of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black)),
                                            Image.network(
                                                'https:${d['day']['condition']['icon']}',
                                                width: 40,
                                                height: 40),
                                            Text(
                                                Temp.fmt(
                                                    d['day']['maxtemp_c'], useF),
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    color: Theme.of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black)),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(height: 20),
                              ],
                            ),
                          const SizedBox(height: 80),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class WeeklyChartPage extends StatelessWidget {
  final List<dynamic> dailyForecast;
  final bool useF;
  const WeeklyChartPage(
      {super.key, required this.dailyForecast, required this.useF});

  double _convert(double c) => useF ? (c * 9 / 5 + 32) : c;

  @override
  Widget build(BuildContext context) {
    final spots = dailyForecast.asMap().entries.map((e) {
      final max = _convert(e.value['day']['maxtemp_c']);
      return FlSpot(e.key.toDouble(), max);
    }).toList();

    final bottomTitles = dailyForecast
        .map((e) => DateFormat('EEE', 'tr_TR').format(
        DateTime.fromMillisecondsSinceEpoch(e['date_epoch'] * 1000)))
        .toList();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Haftalık Sıcaklık Grafiği'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: LineChart(
          LineChartData(
            titlesData: FlTitlesData(
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 1,
                  getTitlesWidget: (value, meta) =>
                      Text(bottomTitles[value.toInt()]),
                ),
              ),
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (value, meta) =>
                      Text(value.toInt().toString()),
                ),
              ),
            ),
            lineBarsData: [
              LineChartBarData(
                spots: spots,
                isCurved: true,
                barWidth: 3,
                color: Theme.of(context).colorScheme.primary,
                dotData: const FlDotData(show: true),
              ),
            ],
          ),
        ),
      ),
    );
  }
}